# 飞书截图自动发送修复

## 问题描述

截图后飞书不会自动发送图片，只返回截图路径的文本。

## 根本原因

1. **ScreenshotSkill 只返回路径文本**
   - 截图工具返回：`路径: /storage/.../screenshot_xxx.png`
   - 没有实际上传和发送图片

2. **sendFeishuReply 没有图片处理**
   - 只是简单发送文本内容
   - 没有检测截图路径
   - 没有上传和发送图片的逻辑

## OpenClaw 的实现

参考文件：`/Users/qiao/file/forclaw/OpenClaw/extensions/feishu/src/media.ts`

### 上传图片流程

```typescript
// 1. 上传图片获取 imageKey
const { imageKey } = await uploadImageFeishu({
  cfg,
  image: buffer,
  accountId
});

// 2. 使用 imageKey 发送图片消息
return sendImageFeishu({
  cfg,
  to,
  imageKey,
  replyToMessageId,
  replyInThread,
  accountId
});
```

### sendMediaFeishu 函数

```typescript
export async function sendMediaFeishu(params: {
  cfg: ClawdbotConfig;
  to: string;
  mediaUrl?: string;
  mediaBuffer?: Buffer;
  fileName?: string;
  replyToMessageId?: string;
  replyInThread?: boolean;
  accountId?: string;
  mediaLocalRoots?: readonly string[];
}): Promise<SendMediaResult> {
  // ...加载图片 Buffer

  // 判断是否是图片
  const isImage = [".jpg", ".jpeg", ".png", ".gif", ...].includes(ext);

  if (isImage) {
    // 上传图片
    const { imageKey } = await uploadImageFeishu({ cfg, image: buffer, accountId });
    // 发送图片消息
    return sendImageFeishu({ cfg, to, imageKey, replyToMessageId, replyInThread, accountId });
  }
}
```

## 解决方案

### 1. 在 FeishuChannel 添加便捷方法

```kotlin
/**
 * 上传并发送图片文件
 * 对齐 OpenClaw sendMediaFeishu
 */
suspend fun uploadAndSendImage(
    imageFile: java.io.File,
    receiveId: String,
    receiveIdType: String = "open_id"
): Result<String> {
    return try {
        val media = FeishuMedia(config, client)

        // 1. 上传图片
        val uploadResult = media.uploadImage(imageFile)
        if (uploadResult.isFailure) {
            return Result.failure(uploadResult.exceptionOrNull()!!)
        }
        val imageKey = uploadResult.getOrNull()!!.key

        // 2. 发送图片消息
        media.sendImage(receiveId, imageKey, receiveIdType)
    } catch (e: Exception) {
        Log.e(TAG, "Failed to upload and send image", e)
        Result.failure(e)
    }
}
```

### 2. 修改 sendFeishuReply 检测并发送截图

```kotlin
/**
 * 发送回复到飞书
 *
 * 对齐 OpenClaw 逻辑：
 * - 检测截图路径并自动上传发送图片
 * - 支持图片 + 文本组合回复
 */
private suspend fun sendFeishuReply(
    event: FeishuEvent.Message,
    content: String
) {
    try {
        Log.i(TAG, "📤 发送回复到飞书...")

        // 检测是否包含截图路径（格式：路径: /storage/.../screenshot_xxx.png）
        val screenshotPathRegex = Regex("""路径:\s*(/storage/[^\s\n]+\.png)""")
        val screenshotMatch = screenshotPathRegex.find(content)

        if (screenshotMatch != null) {
            val screenshotPath = screenshotMatch.groupValues[1]
            Log.i(TAG, "📸 检测到截图路径: $screenshotPath")

            // 1. 上传并发送图片
            val imageFile = File(screenshotPath)
            if (imageFile.exists()) {
                try {
                    Log.i(TAG, "📤 上传图片到飞书...")

                    val imageResult = feishuChannel?.uploadAndSendImage(
                        imageFile = imageFile,
                        receiveId = event.chatId,
                        receiveIdType = "chat_id"
                    )

                    if (imageResult?.isSuccess == true) {
                        Log.i(TAG, "✅ 图片上传并发送成功")
                    } else {
                        Log.e(TAG, "❌ 图片上传失败")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "上传截图失败", e)
                }
            } else {
                Log.w(TAG, "⚠️ 截图文件不存在: $screenshotPath")
            }

            // 2. 发送文本回复（移除截图路径信息）
            val textContent = content
                .replace(screenshotPathRegex, "")
                .trim()

            if (textContent.isNotEmpty()) {
                val result = feishuChannel?.sendMessage(
                    receiveId = event.chatId,
                    receiveIdType = "chat_id",
                    content = textContent
                )

                if (result?.isSuccess == true) {
                    Log.i(TAG, "✅ 文本回复发送成功")
                }
            }
        } else {
            // 没有截图，直接发送文本
            val result = feishuChannel?.sendMessage(
                receiveId = event.chatId,
                receiveIdType = "chat_id",
                content = content
            )

            if (result?.isSuccess == true) {
                Log.i(TAG, "✅ 回复发送成功")
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "发送飞书回复失败", e)
    }
}
```

## 工作流程

### 完整流程

```
用户: "截图"
  ↓
ScreenshotSkill 执行
  ↓
返回结果: "【截图信息】\n分辨率: 1156×2510\n路径: /storage/.../screenshot_xxx.png\n..."
  ↓
processFeishuMessage() 处理
  ↓
sendFeishuReply() 检测到截图路径
  ↓
① uploadAndSendImage() 上传并发送图片
  ├─ uploadImage() → imageKey
  └─ sendImage() → messageId
  ↓
② 发送文本回复（去除路径信息）
  └─ sendMessage() → messageId
  ↓
飞书收到：
  ├─ [图片消息] 📸
  └─ [文本消息] "【截图信息】\n分辨率: 1156×2510\n【屏幕 UI 元素】..."
```

### 对比修复前后

| 操作 | 修复前 | 修复后 |
|------|--------|--------|
| 用户发送 "截图" | 只返回路径文本 | 自动发送图片 + 文本 |
| 飞书收到 | "路径: /storage/.../screenshot.png" | [图片] + UI 元素列表 |
| 体验 | ❌ 需要手动复制路径查看图片 | ✅ 直接看到截图 |

## 技术细节

### 截图路径检测

使用正则表达式检测截图路径：
```kotlin
val screenshotPathRegex = Regex("""路径:\s*(/storage/[^\s\n]+\.png)""")
val screenshotMatch = screenshotPathRegex.find(content)
```

匹配格式：
- `路径: /storage/emulated/0/.../screenshot_1234567.png`
- `路径:/storage/...` (支持无空格)

### 图片上传 API

```kotlin
// 飞书图片上传 API
POST /open-apis/im/v1/images

// 请求体（multipart/form-data）
{
  "image_type": "message",
  "image": <file>
}

// 响应
{
  "code": 0,
  "msg": "success",
  "data": {
    "image_key": "img_v2_xxx"
  }
}
```

### 图片发送 API

```kotlin
// 飞书图片消息发送 API
POST /open-apis/im/v1/messages?receive_id_type=chat_id

// 请求体
{
  "receive_id": "oc_xxx",
  "msg_type": "image",
  "content": "{\"image_key\":\"img_v2_xxx\"}"
}

// 响应
{
  "code": 0,
  "msg": "success",
  "data": {
    "message_id": "om_xxx"
  }
}
```

## 已修改文件

1. **extensions/feishu/src/main/java/com/xiaomo/feishu/FeishuChannel.kt**
   - 添加 `uploadAndSendImage()` 方法

2. **app/src/main/java/com/xiaomo/androidforclaw/core/MyApplication.kt**
   - 修改 `sendFeishuReply()` 方法
   - 添加截图路径检测
   - 添加自动上传和发送图片逻辑

## 测试用例

### 测试 1：基本截图

**输入**：用户发送 "截图"

**预期结果**：
- ✅ 飞书收到图片消息
- ✅ 飞书收到文本消息（UI 元素列表）
- ✅ 日志显示 "✅ 图片上传并发送成功"

### 测试 2：截图文件不存在

**输入**：返回的路径不存在

**预期结果**：
- ❌ 不发送图片
- ✅ 仍然发送文本回复
- ⚠️ 日志显示 "截图文件不存在"

### 测试 3：普通消息（无截图）

**输入**：用户发送 "打开微信"

**预期结果**：
- ✅ 正常发送文本回复
- ✅ 不尝试上传图片
- ✅ 功能不受影响

### 测试 4：连续截图

**输入**：
1. 用户发送 "截图"
2. 等待图片发送完成
3. 再次发送 "截图"

**预期结果**：
- ✅ 两次都成功发送图片
- ✅ 无冲突和错误

## 优化建议

### 1. 支持其他图片格式

目前只检测 `.png`，可以扩展支持：
```kotlin
val screenshotPathRegex = Regex("""路径:\s*(/storage/[^\s\n]+\.(png|jpg|jpeg|webp))""")
```

### 2. 支持多张图片

如果消息中包含多个图片路径，可以依次上传：
```kotlin
val allMatches = screenshotPathRegex.findAll(content)
for (match in allMatches) {
    val path = match.groupValues[1]
    // 上传并发送
}
```

### 3. 图片压缩

对于大图片，可以先压缩再上传：
```kotlin
fun compressImage(file: File, maxSizeMb: Double): File {
    // 压缩逻辑
}
```

### 4. 缓存 imageKey

如果同一张图片需要多次发送，可以缓存 imageKey：
```kotlin
val imageKeyCache = mutableMapOf<String, String>()
```

### 5. 进度提示

上传大图片时显示进度：
```kotlin
Log.i(TAG, "⏳ 正在上传图片...")
feishuChannel?.addReaction(messageId, "HOURGLASS")
```

## 与 OpenClaw 的对齐

| 特性 | OpenClaw | AndroidForClaw |
|------|----------|----------------|
| 自动检测图片路径 | ✅ | ✅ |
| 上传图片获取 imageKey | ✅ | ✅ |
| 发送图片消息 | ✅ | ✅ |
| 图片 + 文本组合 | ✅ | ✅ |
| 支持本地文件路径 | ✅ | ✅ |
| 支持 HTTP URL | ✅ | ❌ (未实现) |
| 图片格式检测 | ✅ | ✅ |
| 文件大小限制 | ✅ (30MB) | ✅ (30MB) |

## 已知限制

1. **HTTP URL 不支持** - 目前只支持本地文件路径
2. **单图片** - 一次只能处理一张图片
3. **固定格式检测** - 必须是 "路径: ..." 格式
4. **无进度提示** - 上传时用户不知道进度

## 后续优化

1. **支持 HTTP URL** - 下载远程图片并上传
2. **支持多图片** - 一次消息发送多张图片
3. **更智能的检测** - 检测任何文件路径
4. **上传进度** - 显示上传进度百分比
5. **错误重试** - 上传失败自动重试
6. **图片优化** - 自动压缩大图片

---

**版本**: v2.4.4
**日期**: 2026-03-07
**修复人**: Claude Code
