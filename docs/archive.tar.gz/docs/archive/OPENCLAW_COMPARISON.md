# phoneforclaw vs OpenClaw 详细对比

**对比日期**: 2026-03-07
**OpenClaw 路径**: ../openclaw
**phoneforclaw 路径**: .

---

## 📊 功能对比总览

| 类别 | OpenClaw | phoneforclaw | 状态 |
|------|----------|--------------|------|
| **核心工具** | 37+ | 26 | ⚠️ 缺11+ |
| **Skills 系统** | ✅ | ✅ | ✅ |
| **Agent Loop** | ✅ | ✅ | ✅ |
| **Gateway** | ✅ 完整 | 🚧 部分 | ⚠️ |
| **多渠道** | 8+ (Telegram/Slack/Discord等) | 2 (飞书/Discord) | ⚠️ |
| **Memory 系统** | ✅ | ✅ | ✅ |
| **配置系统** | ✅ models.json | ✅ models.json | ✅ |
| **Browser 集成** | ✅ | 🚧 基础 | ⚠️ |
| **测试覆盖率** | 90%+ | ~30% | ❌ |

---

## 🔧 工具对比

### ✅ 已实现的工具 (26个)

| phoneforclaw | OpenClaw 对应 | 说明 |
|--------------|--------------|------|
| ReadFile | read | ✅ 完全对齐 |
| WriteFile | write | ✅ 完全对齐 |
| EditFile | edit | ✅ 完全对齐 |
| ListDir | (内置于 fs tools) | ✅ 实现 |
| Exec | exec | ✅ 完全对齐 |
| JavaScriptExecutor | (JS runtime) | ✅ QuickJS |
| WebFetch | web_fetch | ✅ 完全对齐 |
| MemoryGet | memory_get | ✅ 完全对齐 |
| MemorySearch | memory_search | ✅ 完全对齐 |
| Screenshot | (Android specific) | ✅ 平台特定 |
| Tap | (Android specific) | ✅ 平台特定 |
| Swipe | (Android specific) | ✅ 平台特定 |
| Type | (Android specific) | ✅ 平台特定 |
| LongPress | (Android specific) | ✅ 平台特定 |
| Home | (Android specific) | ✅ 平台特定 |
| Back | (Android specific) | ✅ 平台特定 |
| OpenApp | (Android specific) | ✅ 平台特定 |
| GetViewTree | (Android specific) | ✅ 平台特定 |
| ListInstalledApps | (Android specific) | ✅ 平台特定 |
| StartActivity | (Android specific) | ✅ 平台特定 |
| Wait | (control flow) | ✅ 实现 |
| Stop | (control flow) | ✅ 实现 |
| Log | (logging) | ✅ 实现 |

### ❌ 缺失的工具 (11+个)

| OpenClaw 工具 | 说明 | 优先级 |
|--------------|------|--------|
| **apply_patch** | 应用 Git 补丁 | 🔴 HIGH |
| **process** | 后台进程管理 | 🔴 HIGH |
| **web_search** | 网页搜索 | 🔴 HIGH |
| **browser** | 浏览器控制 | 🟡 MEDIUM |
| **gateway** | Gateway 管理 | 🟡 MEDIUM |
| **sessions_list** | 列出所有会话 | 🟡 MEDIUM |
| **sessions_send** | 向其他会话发送消息 | 🟡 MEDIUM |
| **sessions_spawn** | 创建新会话 | 🟡 MEDIUM |
| **session_status** | 获取会话状态 | 🟡 MEDIUM |
| **sessions_history** | 获取会话历史 | 🟢 LOW |
| **agents_list** | 列出所有 agents | 🟢 LOW |
| **subagents** | 子 agent 管理 | 🟢 LOW |
| **canvas** | Canvas 操作 | 🟢 LOW |
| **image** | 图片处理 | 🟢 LOW |
| **tts** | 文字转语音 | 🟢 LOW |
| **cron** | 定时任务 | 🟢 LOW |
| **message** | 消息操作 | 🟡 MEDIUM |

---

## 🏗️ 架构对比

### Agent Loop

| 特性 | OpenClaw | phoneforclaw | 状态 |
|------|----------|--------------|------|
| **基本循环** | LLM → Tools → Observation | LLM → Tools → Observation | ✅ |
| **Extended Thinking** | ✅ | ✅ | ✅ |
| **Tool Calling** | ✅ Function Calling | ✅ Function Calling | ✅ |
| **最大迭代** | 可配置 | 40（硬编码） | ⚠️ |
| **停止机制** | stop tool | stop tool | ✅ |
| **进度追踪** | ✅ | ✅ progressFlow | ✅ |
| **错误处理** | ✅ 完善 | ⚠️ 基础 | ⚠️ |

### Skills 系统

| 特性 | OpenClaw | phoneforclaw | 状态 |
|------|----------|--------------|------|
| **Skill 格式** | Markdown + Frontmatter | Markdown + Frontmatter | ✅ |
| **三层加载** | Bundled/Managed/Workspace | Bundled/Managed/Workspace | ✅ |
| **Hot Reload** | ✅ | ✅ | ✅ |
| **优先级覆盖** | Workspace > Managed > Bundled | Workspace > Managed > Bundled | ✅ |
| **On-demand 加载** | ✅ | 🚧 | ⚠️ |
| **Skill Gating** | ✅ requires.bins/config | ❌ | ❌ |
| **AgentSkills.io** | ✅ 兼容 | ✅ 兼容 | ✅ |

### 配置系统

| 特性 | OpenClaw | phoneforclaw | 状态 |
|------|----------|--------------|------|
| **models.json** | ✅ | ✅ | ✅ |
| **openclaw.json** | ✅ | ✅ | ✅ |
| **环境变量替换** | ✅ ${VAR} | ❌ | ❌ |
| **Provider 配置** | ✅ 多 provider | ✅ 多 provider | ✅ |
| **Model 切换** | ✅ 运行时切换 | ⚠️ 启动时配置 | ⚠️ |
| **Thinking 配置** | ✅ | ✅ | ✅ |
| **Cost 追踪** | ✅ | ❌ | ❌ |

### Gateway

| 特性 | OpenClaw | phoneforclaw | 状态 |
|------|----------|--------------|------|
| **WebSocket 服务器** | ✅ | 🚧 规划中 | ❌ |
| **多会话管理** | ✅ | ⚠️ 基础 SessionManager | ⚠️ |
| **设备配对** | ✅ | ❌ | ❌ |
| **安全认证** | ✅ | ❌ | ❌ |
| **Allow List** | ✅ | ❌ | ❌ |
| **Rate Limiting** | ✅ | ❌ | ❌ |
| **Health Check** | ✅ | ❌ | ❌ |

### 渠道集成

| 渠道 | OpenClaw | phoneforclaw | 状态 |
|------|----------|--------------|------|
| **Telegram** | ✅ 完整 | ❌ | ❌ |
| **Slack** | ✅ 完整 | ❌ | ❌ |
| **Discord** | ✅ 完整 | ✅ 部分 | ⚠️ |
| **WhatsApp** | ✅ | ❌ | ❌ |
| **Signal** | ✅ | ❌ | ❌ |
| **iMessage** | ✅ | ❌ | ❌ |
| **LINE** | ✅ | ❌ | ❌ |
| **飞书** | ❌ | ✅ 完整 | ✅ |
| **Web UI** | ✅ | 🚧 | ⚠️ |

---

## 📦 模块对比

### 核心模块

| 模块 | OpenClaw | phoneforclaw | 差异 |
|------|----------|--------------|------|
| **src/agents/** | 495 文件 | agent/ 目录 | OpenClaw 更全面 |
| **src/commands/** | 271 文件 | ❌ | 缺失命令系统 |
| **src/gateway/** | 219 文件 | 🚧 规划中 | 核心差异 |
| **src/config/** | 199 文件 | config/ 目录 | 基本对齐 |
| **src/memory/** | 92 文件 | agent/memory/ | ⚠️ 简化版 |
| **src/browser/** | 124 文件 | agent/skills/browser/ | ⚠️ 基础版 |
| **src/infra/** | 289 文件 | 分散在多处 | 需要重构 |

### 基础设施

| 功能 | OpenClaw | phoneforclaw | 状态 |
|------|----------|--------------|------|
| **日志系统** | structured logging | Android Log | ⚠️ 平台差异 |
| **错误处理** | 统一错误类型 | 基础异常 | ⚠️ |
| **性能监控** | ✅ | ❌ | ❌ |
| **安全策略** | 完善 | 基础 | ⚠️ |
| **文件锁** | ✅ | ❌ | ❌ |
| **进程管理** | ✅ | ⚠️ Android 特定 | ⚠️ |

---

## 🧪 测试对比

| 测试类型 | OpenClaw | phoneforclaw | 差距 |
|---------|----------|--------------|------|
| **单元测试** | 1000+ | 24 | 巨大 |
| **集成测试** | 500+ | 0 | 巨大 |
| **E2E 测试** | 100+ | 0 | 巨大 |
| **覆盖率** | 90%+ | 30% | 巨大 |
| **CI/CD** | ✅ GitHub Actions | ❌ | 缺失 |
| **性能测试** | ✅ | ❌ | 缺失 |

---

## 🎯 需要实现的功能清单

### 🔴 高优先级（立即实现）

1. **apply_patch 工具**
   - 应用 Git 补丁
   - 对应文件：需要新建 `ApplyPatchTool.kt`

2. **process 工具**
   - 后台进程管理
   - 对应文件：需要新建 `ProcessTool.kt`

3. **web_search 工具**
   - 网页搜索
   - 对应文件：需要新建 `WebSearchTool.kt`

4. **环境变量替换**
   - 配置文件支持 `${VAR}`
   - 修改文件：`config/ConfigLoader.kt`

5. **Cost 追踪**
   - Token usage 统计
   - 对应文件：需要新建 `CostTracker.kt`

6. **完善错误处理**
   - 统一错误类型
   - 修改文件：`agent/tools/Skill.kt`

### 🟡 中优先级（尽快实现）

7. **Sessions 管理工具**
   - sessions_list
   - sessions_send
   - sessions_spawn
   - session_status
   - 对应文件：需要扩展 `agent/session/SessionManager.kt`

8. **Gateway 核心**
   - WebSocket 服务器
   - 设备配对
   - 安全认证
   - 对应目录：需要新建 `gateway/`

9. **Browser 工具增强**
   - 完整的浏览器控制
   - 修改文件：`agent/skills/BrowserForClawSkill.kt`

10. **Message 工具**
    - 消息操作抽象
    - 对应文件：需要新建 `MessageTool.kt`

11. **On-demand Skill 加载**
    - 按需加载 Skills
    - 修改文件：`agent/skills/SkillsLoader.kt`

12. **Skill Gating**
    - requires.bins
    - requires.config
    - 修改文件：`agent/skills/SkillLoader.kt`

### 🟢 低优先级（未来考虑）

13. **agents_list 工具**
14. **subagents 工具**
15. **canvas 工具**
16. **image 工具**
17. **tts 工具**
18. **cron 工具**
19. **sessions_history 工具**

---

## 📐 架构差异分析

### OpenClaw 的优势

1. **完整的 Gateway 架构**
   - 多设备配对
   - 安全认证
   - 会话管理
   - Health check

2. **丰富的渠道支持**
   - 8+ 个消息平台
   - 统一的接口抽象

3. **完善的测试**
   - 90%+ 覆盖率
   - E2E 测试
   - 性能基准

4. **强大的命令系统**
   - 271 个命令文件
   - 完善的 CLI

5. **基础设施成熟**
   - 错误处理
   - 日志系统
   - 性能监控

### phoneforclaw 的优势

1. **Android 平台集成**
   - Accessibility Service
   - 屏幕操作
   - UI 树分析
   - 应用管理

2. **飞书深度集成**
   - 完整的飞书 API
   - Markdown 卡片
   - 表情回复

3. **QuickJS 集成**
   - JavaScript 执行
   - 轻量级引擎

4. **MMKV 存储**
   - 快速配置存储

---

## 🚀 实施计划

### 第一阶段：核心工具补全（1-2周）

- [ ] implement apply_patch
- [ ] implement process
- [ ] implement web_search
- [ ] 环境变量替换
- [ ] Cost 追踪

### 第二阶段：Sessions 和 Gateway（2-3周）

- [ ] 完善 SessionManager
- [ ] implement sessions_* tools
- [ ] Gateway WebSocket 服务器
- [ ] 设备配对机制

### 第三阶段：测试覆盖（1-2周）

- [ ] 单元测试覆盖到 80%+
- [ ] 集成测试
- [ ] E2E 测试
- [ ] CI/CD 配置

### 第四阶段：优化和完善（持续）

- [ ] 性能优化
- [ ] 错误处理完善
- [ ] 文档完善
- [ ] 更多渠道集成

---

## 📝 代码对齐检查清单

### 配置系统
- [x] models.json 格式对齐
- [x] ModelConfig 数据结构对齐
- [x] ProviderConfig 对齐
- [ ] 环境变量替换
- [ ] Cost 配置

### Agent Loop
- [x] 基本循环结构
- [x] Extended Thinking
- [x] Tool Calling
- [ ] 动态 max iterations
- [ ] 完善错误处理

### Tools
- [x] read, write, edit
- [x] exec
- [x] web_fetch
- [x] memory_get, memory_search
- [ ] apply_patch
- [ ] process
- [ ] web_search
- [ ] browser (enhanced)

### Skills
- [x] Markdown 格式
- [x] 三层加载
- [x] Hot Reload
- [ ] On-demand 加载
- [ ] Skill Gating

### Gateway
- [ ] WebSocket 服务器
- [ ] 多会话管理
- [ ] 设备配对
- [ ] 安全认证
- [ ] Rate Limiting

---

**最后更新**: 2026-03-07
**对比者**: Claude Opus 4.6
**参考**: [CLAUDE.md](CLAUDE.md), [OpenClaw GitHub](https://github.com/openclaw/openclaw)
