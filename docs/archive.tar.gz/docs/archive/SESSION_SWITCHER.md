# Session 切换功能

## 概述

手机端现在支持和 OpenClaw 一样的多 session 切换功能。用户可以在聊天界面顶部切换不同的对话会话。

## 功能特性

### 1. Session 控制栏

位于聊天界面顶部，包含：
- **Session 选择器** - 下拉菜单显示所有可用 session
- **新建按钮** - 快速创建新对话

### 2. Session 显示

每个 session 显示：
- **标题** - 根据首条用户消息自动生成（或默认"新对话"）
- **创建时间** - 相对时间格式（刚刚、X分钟前、X小时前、日期时间）
- **激活状态** - 当前活跃 session 加粗显示

### 3. 自动标题生成

- 当用户发送第一条消息后，自动根据消息内容生成 session 标题
- 超过 20 字符自动截断（显示前 20 字 + "..."）
- 示例：
  - 用户消息："打开微信" → Session 标题："打开微信"
  - 用户消息："帮我测试一下登录功能是否正常工作" → Session 标题："帮我测试一下登录功能是否正..."

### 4. Session 管理

- **创建新 session** - 点击顶部的 "+" 按钮
- **切换 session** - 点击下拉菜单选择不同的 session
- **保留历史** - 每个 session 独立保存消息历史

## 实现细节

### 参考 OpenClaw 设计

本实现参考了 OpenClaw 的 session 切换设计：
- **简单选择器模式** - 使用原生下拉菜单（Android 上使用 DropdownMenu）
- **智能显示名称** - 自动生成人类可读的 session 名称
- **状态同步** - 切换 session 时自动更新消息列表

### UI 组件

#### SessionControlBar
```kotlin
@Composable
fun SessionControlBar(
    sessions: List<SessionManager.Session>,
    currentSession: SessionManager.Session?,
    onSessionChange: (String) -> Unit,
    onNewSession: () -> Unit,
    modifier: Modifier = Modifier
)
```

**功能：**
- 显示当前 session 标题
- 下拉菜单选择 session
- 新建 session 按钮

**样式：**
- 灰色背景 (#F7F7F7)
- 圆角输入框
- 蓝色新建按钮
- 2dp 阴影

### 数据流

```
ChatViewModel
  ├── sessions: StateFlow<List<Session>>          # 所有 session 列表
  ├── currentSession: StateFlow<Session>          # 当前活跃 session
  ├── messages: StateFlow<List<ChatMessage>>      # 当前 session 的消息
  │
  ├── createNewSession()                          # 创建新 session
  ├── switchSession(sessionId)                    # 切换 session
  └── sendMessage(content)                        # 发送消息（自动生成标题）
```

### SessionManager (UI)

位于 `com.xiaomo.androidforclaw.ui.session.SessionManager`

**主要功能：**
- `createSession()` - 创建新会话
- `switchSession(sessionId)` - 切换会话
- `deleteSession(sessionId)` - 删除会话
- `autoGenerateCurrentSessionTitle()` - 自动生成标题
- `clearCurrentSession()` - 清空当前会话

**数据结构：**
```kotlin
data class Session(
    val id: String,                   # UUID
    val title: String,                # 标题
    val createdAt: Long,              # 创建时间戳
    val messages: List<ChatMessage>,  # 消息列表
    val isActive: Boolean             # 是否激活
)
```

## 使用方法

### 对于用户

1. **查看当前 session**
   - 打开对话 Tab
   - 顶部显示当前 session 名称

2. **切换 session**
   - 点击顶部的 session 名称
   - 在下拉菜单中选择其他 session

3. **创建新 session**
   - 点击顶部的蓝色 "+" 按钮
   - 新 session 会自动激活

4. **自动命名**
   - 发送第一条消息后，session 会自动根据消息内容命名
   - 例如：发送"打开微信" → session 名称变为"打开微信"

### 对于开发者

#### 添加 Session 控制栏到新界面

```kotlin
@Composable
fun YourChatScreen(viewModel: ChatViewModel) {
    val messages by viewModel.messages.collectAsState()
    val sessions by viewModel.sessions.collectAsState()
    val currentSession by viewModel.currentSession.collectAsState()

    ChatScreen(
        messages = messages,
        onSendMessage = { viewModel.sendMessage(it) },
        sessions = sessions,
        currentSession = currentSession,
        onSessionChange = { viewModel.switchSession(it) },
        onNewSession = { viewModel.createNewSession() }
    )
}
```

#### 自定义 Session 标题

```kotlin
// 手动设置标题
sessionManager.updateCurrentSessionTitle("自定义标题")

// 自动生成标题
sessionManager.autoGenerateCurrentSessionTitle()
```

#### 访问 Session 数据

```kotlin
// 获取所有 session
val allSessions = sessionManager.getAllSessions()

// 获取 session 数量
val count = sessionManager.getSessionCount()

// 清空当前 session
sessionManager.clearCurrentSession()
```

## 与 OpenClaw 的对比

| 特性 | OpenClaw | AndroidForClaw |
|------|----------|----------------|
| Session 选择器 | HTML `<select>` | Compose DropdownMenu |
| 显示位置 | 顶部控制栏 | 顶部控制栏 |
| 新建 session | + 按钮 | + 按钮 |
| 自动标题 | 基于首条消息 | 基于首条消息 |
| 时间格式 | 相对时间 | 相对时间 |
| Session 过滤 | 支持（隐藏 cron） | 不支持 |
| URL 同步 | 支持 | 不支持 |

## 已知限制

1. **URL 同步** - 暂不支持通过 URL 参数传递 session
2. **Session 过滤** - 暂不支持按类型过滤 session
3. **Session 元数据** - 暂不支持 thinking level、verbose level 等配置
4. **Session 持久化** - 暂不支持跨应用重启保存 session（计划中）

## 后续计划

1. **Session 持久化** - 使用 MMKV 或 Room 保存 session 到本地
2. **Session 同步** - 与 Agent 的 SessionManager 同步
3. **Session 元数据** - 支持配置 thinking level、reasoning level 等
4. **Session 管理界面** - 独立的 session 管理页面（查看、编辑、删除）
5. **Session 搜索** - 支持搜索 session 标题和消息内容

## 文件清单

修改的文件：
- `app/src/main/java/com/xiaomo/androidforclaw/ui/compose/ChatScreen.kt` - 添加 SessionControlBar
- `app/src/main/java/com/xiaomo/androidforclaw/ui/activity/MainActivityCompose.kt` - 传递 session 参数
- `app/src/main/java/com/xiaomo/androidforclaw/ui/viewmodel/ChatViewModel.kt` - 添加自动标题生成

已存在的文件：
- `app/src/main/java/com/xiaomo/androidforclaw/ui/session/SessionManager.kt` - Session 管理逻辑
- `app/src/main/java/com/xiaomo/androidforclaw/agent/session/SessionManager.kt` - Agent 的 Session 管理

## 测试

### 手动测试步骤

1. **基本功能测试**
   ```
   1. 打开应用，进入对话 Tab
   2. 验证顶部显示 "新对话"
   3. 发送一条消息："打开微信"
   4. 验证顶部标题变为 "打开微信"
   ```

2. **创建新 session**
   ```
   1. 点击顶部 "+" 按钮
   2. 验证创建了新的 session（标题为"新对话"）
   3. 发送消息，验证标题更新
   ```

3. **切换 session**
   ```
   1. 创建多个 session（至少 3 个）
   2. 点击顶部 session 名称
   3. 验证下拉菜单显示所有 session
   4. 选择不同的 session
   5. 验证消息列表切换到对应的 session
   ```

4. **长标题测试**
   ```
   1. 创建新 session
   2. 发送长消息："这是一条非常非常非常长的消息用来测试标题截断功能"
   3. 验证标题显示为："这是一条非常非常非常长的消息用..."（前 20 字 + "..."）
   ```

5. **时间显示测试**
   ```
   1. 创建新 session
   2. 立即打开下拉菜单，验证显示 "刚刚"
   3. 等待 2 分钟后打开，验证显示 "2 分钟前"
   ```

### 预期行为

- Session 切换应该是即时的，无延迟
- 标题应该在发送第一条用户消息后立即更新
- 下拉菜单应该显示所有 session，当前 session 加粗
- 创建新 session 应该自动切换到新 session

## 截图

（TODO: 添加 UI 截图）

---

**版本**: v2.4.3
**日期**: 2026-03-07
**作者**: Claude Code
