# Tools vs Skills - AndroidForClaw 架构指南

参考 OpenClaw 的设计理念，明确 Tools 和 Skills 的区别和职责。

## 📐 核心理念

```
Tools (工具)              Skills (技能)
────────────────         ────────────────
代码实现的能力            Markdown 文档
底层、通用                上层、特定领域
Coding Agent 提供的       教 Agent 如何使用 Tools
```

## 🔧 Tools (工具)

**定义**: 代码实现的底层通用能力，通常跨平台、跨场景通用。

**来源**: OpenClaw 的 Pi Coding Agent 工具集

### OpenClaw 的标准 Tools

1. **文件操作** (来自 pi-coding-agent)
   - `read` - 读取文件
   - `write` - 写入文件
   - `edit` - 编辑文件（精确替换）

2. **Shell 操作**
   - `bash` - 执行 shell 命令
   - `process` - 管理后台进程（list, poll, log, kill）

3. **网络操作**
   - `web_fetch` - 获取网页内容
   - `web_search` - 网页搜索

4. **Gateway 操作**
   - `message` - 发送消息到其他 Channel
   - `sessions` - 管理会话
   - `agents` - 多 Agent 协作

5. **扩展工具**
   - `browser` - 浏览器自动化（Playwright）
   - `image` - 图像处理
   - `canvas` - 画布操作

### AndroidForClaw 应该提供的 Tools

**保持通用性原则** - Tools 应该是底层能力，不绑定特定使用场景。

#### ✅ 应该是 Tools (通用底层能力)

1. **文件操作** (已有，来自 ToolRegistry)
   - `read_file` - 读取文件
   - `write_file` - 写入文件
   - `edit_file` - 编辑文件
   - `list_dir` - 列出目录

2. **Shell 操作** (已有)
   - `exec` - 执行命令
   - `javascript` - 执行 JS 代码（QuickJS）

3. **网络操作** (已有)
   - `web_fetch` - 获取网页

4. **浏览器操作** (已有)
   - `browser` - BrowserForClaw 集成

#### ❌ 不应该是 Tools (特定于 Android)

这些是 **Android 特定的能力**，应该放在 **Skills** 中：

- ~~`tap`~~ - Android 点击
- ~~`swipe`~~ - Android 滑动
- ~~`type`~~ - Android 输入
- ~~`screenshot`~~ - Android 截图
- ~~`get_view_tree`~~ - Android UI 树
- ~~`open_app`~~ - Android 打开应用
- ~~`list_installed_apps`~~ - Android 应用列表
- ~~`start_activity`~~ - Android Activity

## 🎯 Skills (技能)

**定义**: Markdown 文档，教 Agent 如何使用 Tools 完成特定领域的任务。

### AndroidForClaw 的 Skills 架构

```
Skills (Markdown 文档)
├── bootstrap.md         # Agent 身份和核心原则
├── mobile-operations.md # Android 操作 (tap, screenshot, etc.)
├── browser.md           # 浏览器控制
├── data-processing.md   # 数据处理
├── javascript-executor.md # JS 执行
├── debugging.md         # 调试
└── create-skill.md      # 元技能
```

### Skills 的职责

1. **提供上下文** - 告诉 Agent 什么时候用什么工具
2. **提供最佳实践** - 如何正确使用工具
3. **提供工作流** - 多个工具的组合使用
4. **领域知识** - 特定场景的专业知识

## 🏗️ AndroidForClaw 重构方案

### 当前问题

❌ **混淆了 Tools 和 Skills**:
- 把 Android 特定能力（tap, screenshot）当作 Tools 注册在 `SkillRegistry`
- `SkillRegistry` 同时管理 Tools（代码）和 Skills（Markdown）
- 命名混乱：`SkillRegistry` 实际包含 Tools

### 正确架构

```
ToolRegistry (通用底层工具)
├── read_file
├── write_file
├── edit_file
├── exec
├── web_fetch
├── browser
└── javascript

SkillRegistry (Skills 加载器)
├── 加载 assets/skills/*.md
├── 加载 workspace/skills/*.md
└── 注入 System Prompt

Android Platform (平台特定实现)
├── AccessibilityService
│   ├── tap(x, y)
│   ├── swipe(...)
│   ├── type(text)
│   └── getViewTree()
├── MediaProjection
│   └── screenshot()
└── PackageManager
    ├── listInstalledApps()
    └── startActivity()
```

### 实现方案

#### 方案 A: 创建 PlatformRegistry (推荐)

```kotlin
// 新增 PlatformRegistry - 管理 Android 特定能力
class PlatformRegistry(context: Context) {
    private val tools = mutableMapOf<String, Skill>()

    init {
        // Android 观察类
        register(ScreenshotSkill(context))
        register(GetViewTreeSkill(context))

        // Android 交互类
        register(TapSkill())
        register(SwipeSkill())
        register(TypeSkill(context))
        register(LongPressSkill())

        // Android 导航类
        register(HomeSkill())
        register(BackSkill())
        register(OpenAppSkill(context))

        // Android 应用管理
        register(ListInstalledAppsSkill(context))
        register(StartActivitySkill(context))

        // 等待和控制
        register(WaitSkill())
        register(StopSkill(taskDataManager))
        register(LogSkill())
    }
}

// 主入口整合
class AgentLoop(...) {
    private val toolRegistry = ToolRegistry(...)      // 通用工具
    private val platformRegistry = PlatformRegistry(...) // Android 平台
    private val skillsLoader = SkillsLoader(...)     // Skills 文档

    fun getAllToolDefinitions() {
        return toolRegistry.getToolDefinitions() +
               platformRegistry.getToolDefinitions()
    }

    fun getSystemPrompt() {
        return buildString {
            appendLine(toolRegistry.getToolsDescription())
            appendLine(platformRegistry.getToolsDescription())
            appendLine(skillsLoader.getSkillsContent())
        }
    }
}
```

#### 方案 B: 重命名 SkillRegistry 为 PlatformToolRegistry

```kotlin
// 重命名
SkillRegistry -> PlatformToolRegistry

// 职责：仅管理 Android 平台特定的工具
// 不再加载 Skills Markdown 文件
```

#### 方案 C: 合并到 ToolRegistry（不推荐）

把所有 Android 工具注册到 ToolRegistry，但这违反了"Tools 应该通用"的原则。

## ✅ 推荐行动

1. **立即行动** - 重命名清晰化
   - `SkillRegistry` → `AndroidToolRegistry` 或 `PlatformRegistry`
   - 分离 Skills 加载逻辑到独立的 `SkillsLoader`

2. **中期优化** - 架构对齐
   - `ToolRegistry` 只包含通用工具（read, write, exec, web_fetch）
   - `PlatformRegistry` 包含 Android 特定工具（tap, screenshot, etc.）
   - `SkillsLoader` 只负责加载 Markdown Skills

3. **长期规划** - 扩展性
   - 其他平台（iOS, macOS, Windows）可以创建自己的 PlatformRegistry
   - Skills 可跨平台复用（mobile-operations 适配不同平台）

## 📚 参考

- OpenClaw: `/Users/qiao/file/clawdbot/openclaw/src/agents/pi-tools.ts`
- Pi Coding Agent: `@mariozechner/pi-coding-agent`
- Skills: `/Users/qiao/file/clawdbot/openclaw/skills/`

---

**总结**: Tools 是代码，Skills 是知识。Android 特定能力不应该叫 "Tools"，而应该叫 "Platform Capabilities"。
