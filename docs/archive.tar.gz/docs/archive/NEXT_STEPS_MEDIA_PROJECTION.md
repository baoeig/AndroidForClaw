# 录屏权限拆分到无障碍服务 APK - 实现完成

## ✅ 已完成

1. **无障碍服务拆分** ✓
   - 独立 APK 模块创建
   - AIDL 接口定义
   - 跨进程通讯实现
   - 主应用集成完成
   - 添加应用图标
   - 权限页面更新

2. **主应用更新** ✓
   - 移除无障碍权限申请逻辑
   - 改为显示 AccessibilityProxy 连接状态
   - 所有 UI 界面已更新

3. **录屏权限拆分** ✓ (2026-03-07 完成)
   - MediaProjectionHelper 已移至 accessibility-service 模块
   - ForegroundService 已在 accessibility-service 中实现
   - AIDL 接口已扩展支持截图功能：
     - `isMediaProjectionGranted()` - 检查权限状态
     - `captureScreen()` - 截图并返回文件路径（URI）
     - `getMediaProjectionStatus()` - 获取权限状态描述
   - AccessibilityProxy 已实现截图客户端方法
   - DeviceController 已更新使用跨进程截图
   - MainActivity 权限页面已更新显示 MediaProjection 状态

## 📋 实现详情

### 目标
将 MediaProjection (录屏权限) 也移至 `accessibility-service` 模块，实现统一管理。

### 实现步骤

#### 1. 移动 MediaProjectionHelper 到无障碍服务模块

```kotlin
// 文件位置调整
FROM: app/src/main/java/com/xiaomo/androidforclaw/util/MediaProjectionHelper.kt
TO:   accessibility-service/src/main/java/com/xiaomo/androidforclaw/accessibility/MediaProjectionHelper.kt
```

#### 2. 更新 AIDL 接口

添加截图相关方法到 `IAccessibilityService.aidl`:

```aidl
// 新增方法
byte[] captureScreen();  // 返回PNG格式的截图数据
boolean isMediaProjectionGranted();
String requestMediaProjection();  // 返回请求状态
```

#### 3. 在 AccessibilityBinderService 中实现截图

```kotlin
class AccessibilityBinderService : Service() {
    private val mediaProjectionHelper = MediaProjectionHelper()

    override fun onBind(intent: Intent?): IBinder? {
        when (intent?.action) {
            "com.xiaomo.androidforclaw.ACCESSIBILITY_BIND" -> return binder
            "com.xiaomo.androidforclaw.SCREEN_CAPTURE" -> {
                // 处理录屏权限请求
                return captureScreenBinder
            }
        }
    }

    // 实现截图功能
    private fun captureScreen(): ByteArray? {
        val bitmap = mediaProjectionHelper.captureScreen()
        return bitmap?.let {
            val stream = ByteArrayOutputStream()
            it.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.toByteArray()
        }
    }
}
```

#### 4. 主应用创建 ScreenshotProxy

```kotlin
// app/src/main/java/com/xiaomo/androidforclaw/accessibility/ScreenshotProxy.kt

object ScreenshotProxy {
    private var service: IAccessibilityService? = null

    suspend fun captureScreen(): Pair<Bitmap, String>? = withContext(Dispatchers.IO) {
        val imageData = service?.captureScreen() ?: return@withContext null
        val bitmap = BitmapFactory.decodeByteArray(imageData, 0, imageData.size)

        // 保存到临时文件
        val file = File.createTempFile("screenshot", ".png", cacheDir)
        bitmap to file.absolutePath
    }

    fun isMediaProjectionGranted(): Boolean {
        return try {
            service?.isMediaProjectionGranted() ?: false
        } catch (e: Exception) {
            false
        }
    }
}
```

#### 5. 更新 DeviceController

```kotlin
object DeviceController {
    fun getScreenshot(context: Context): Pair<Bitmap, String>? {
        return runBlocking {
            ScreenshotProxy.captureScreen()
        }
    }
}
```

#### 6. 更新权限页面

在 PermissionsActivity 中：
- 移除录屏权限申请按钮
- 显示 "由无障碍服务提供" 提示

### 优势

1. **统一管理**: 所有系统级权限集中在一个独立 APK
2. **权限持久化**: 录屏权限也只需授予一次
3. **简化主应用**: 主应用无需处理复杂的权限逻辑
4. **独立更新**: 权限服务可以独立升级

### 注意事项

1. **Parcel 大小限制**: AIDL 传输 Bitmap 需要注意大小 (<1MB)
   - 可以考虑压缩或分块传输
   - 或者使用共享内存（SharedMemory）

2. **性能考虑**: 跨进程传输图片会有性能开销
   - 建议添加本地缓存
   - 使用内存共享优化

3. **前台服务**: MediaProjection 需要前台服务
   - 在 accessibility-service 中启动前台服务
   - 更新 Manifest 权限

### 替代方案

如果 AIDL 传输性能不佳，可以考虑：

1. **使用 ContentProvider 共享图片**
   ```kotlin
   // 无障碍服务保存截图到 ContentProvider
   // 主应用通过 URI 读取
   ```

2. **使用 Socket 通讯**
   ```kotlin
   // 建立本地 Socket 连接
   // 传输大数据更高效
   ```

3. **使用共享内存**
   ```kotlin
   // Android Q+ 支持 SharedMemory
   // 零拷贝传输
   ```

## 📝 实现顺序

1. ✅ 无障碍服务拆分
2. ✅ 录屏权限拆分
3. ✅ AIDL 接口扩展
4. ✅ 主应用客户端实现
5. 🔄 性能优化（待评估）
6. ⏳ 测试验证（进行中）

## 🎯 实际效果

**主应用 (com.xiaomo.androidforclaw.debug)**：
- ✅ 不再直接请求无障碍权限
- ✅ 不再直接请求录屏权限
- ✅ 通过 AccessibilityProxy 跨进程调用所有功能
- ✅ UI 显示服务连接状态而非权限状态
- ✅ 用户体验更简洁

**无障碍服务 APK (com.xiaomo.androidforclaw.accessibility)**：
- ✅ 提供无障碍服务（PhoneAccessibilityService）
- ✅ 提供录屏功能（MediaProjectionHelper）
- ✅ 提供 AIDL 接口供主应用调用
- ✅ 独立生命周期，不受主应用影响
- ✅ 权限只需授予一次

## 🔧 如何授予 MediaProjection 权限

由于 MediaProjection 权限需要通过 Activity 请求，而无障碍服务 APK 没有用户界面，因此需要以下步骤：

**方案 1：通过系统设置授予（推荐）**
1. 打开系统设置 → 应用管理
2. 找到"无障碍服务" (com.xiaomo.androidforclaw.accessibility)
3. 授予必要权限

**方案 2：创建权限请求 Activity（待实现）**
```kotlin
// 在 accessibility-service 模块中添加：
class PermissionRequestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MediaProjectionHelper.requestMediaProjection(this)
    }
}
```

**方案 3：主应用代理请求（当前实现）**
- 主应用检测到未授权时提示用户
- 引导用户到系统设置授予权限

## 📊 架构对比

**原架构（同进程）：**
```
androidforclaw (Main App)
├── PhoneAccessibilityService
├── MediaProjectionHelper
└── Tools/Skills
```

**新架构（跨进程 AIDL）：**
```
androidforclaw (Main App)           accessibility-service (Standalone App)
├── AccessibilityProxy              ├── PhoneAccessibilityService
├── Tools/Skills                    ├── MediaProjectionHelper
└── DeviceController                ├── ForegroundService
                                    └── AccessibilityBinder (AIDL)
                    ↕ AIDL IPC
```

## 🧪 测试验证

**已验证：**
1. ✅ 两个 APK 编译成功
2. ✅ AccessibilityBinderService 成功启动
3. ✅ MediaProjectionHelper 目录初始化成功
4. ✅ AIDL 接口绑定成功

**待验证：**
1. ⏳ MediaProjection 权限授予流程
2. ⏳ 截图功能跨进程调用
3. ⏳ 主应用崩溃后截图功能仍可用
4. ⏳ 性能测试（延迟、内存占用）

## 📁 关键文件

**accessibility-service 模块：**
- `MediaProjectionHelper.kt` - 截图核心逻辑
- `ForegroundService.kt` - 前台服务（MediaProjection 需要）
- `AccessibilityBinder.java` - AIDL 实现（包含截图方法）
- `IAccessibilityService.aidl` - AIDL 接口定义
- `AndroidManifest.xml` - 权限和服务声明

**主应用：**
- `AccessibilityProxy.kt` - 客户端包装（新增截图方法）
- `DeviceController.kt` - 更新使用 AccessibilityProxy.captureScreen()
- `MainActivity.kt` - 权限状态显示更新
- `app/src/main/aidl/` - AIDL 接口副本

