# MediaProjection 拆分完成总结

## ✅ 完成日期
2026-03-07

## 🎯 目标
将 MediaProjection（录屏权限）从主应用拆分到独立的无障碍服务 APK 中，实现统一的权限管理。

## ✅ 已完成工作

### 1. MediaProjectionHelper 移至 accessibility-service 模块
**文件位置**：`accessibility-service/src/main/java/com/xiaomo/androidforclaw/accessibility/MediaProjectionHelper.kt`

**修改内容**：
- ✅ 移除对主应用类的依赖（MyApplication, LayoutExceptionLogger）
- ✅ 使用 `Log` 替代 LayoutExceptionLogger
- ✅ 添加 `setScreenshotDirectory()` 方法供外部配置截图目录
- ✅ 更新 `requestMediaProjection()` 接受 Activity 参数
- ✅ 保持所有核心截图功能不变

### 2. 创建 ForegroundService
**文件位置**：`accessibility-service/src/main/java/com/xiaomo/androidforclaw/accessibility/ForegroundService.kt`

**功能**：
- ✅ MediaProjection 需要的前台服务
- ✅ 显示持久通知："无障碍服务正在运行"
- ✅ 低优先级通知，不干扰用户

### 3. 创建 PermissionActivity
**文件位置**：`accessibility-service/src/main/java/com/xiaomo/androidforclaw/accessibility/PermissionActivity.kt`

**功能**：
- ✅ 提供用户界面用于授予 MediaProjection 权限
- ✅ 显示当前权限状态
- ✅ 一键授予录屏权限
- ✅ 刷新状态功能
- ✅ 设置为 LAUNCHER Activity，可从桌面启动
- ✅ Dialog 主题，友好的小窗口界面

### 4. 扩展 AIDL 接口
**文件位置**：`accessibility-service/src/main/aidl/com/xiaomo/androidforclaw/aidl/IAccessibilityService.aidl`

**新增方法**：
```aidl
boolean isMediaProjectionGranted();
String captureScreen();  // 返回截图文件路径（URI）
String getMediaProjectionStatus();  // 获取权限状态描述
```

### 5. 实现 AccessibilityBinder 的截图方法
**文件位置**：`accessibility-service/src/main/java/com/xiaomo/androidforclaw/accessibility/service/AccessibilityBinder.java`

**实现**：
- ✅ `isMediaProjectionGranted()` - 检查权限状态
- ✅ `captureScreen()` - 调用 MediaProjectionHelper 截图，返回文件路径
- ✅ `getMediaProjectionStatus()` - 返回权限状态字符串

### 6. 初始化 MediaProjectionHelper
**文件位置**：`accessibility-service/src/main/java/com/xiaomo/androidforclaw/accessibility/service/AccessibilityBinderService.kt`

**实现**：
- ✅ 在 `onCreate()` 中初始化截图目录
- ✅ 设置截图保存路径：`/storage/emulated/0/Android/data/com.xiaomo.androidforclaw.accessibility/files/Screenshots`

### 7. 实现 AccessibilityProxy 客户端方法
**文件位置**：`app/src/main/java/com/xiaomo/androidforclaw/accessibility/AccessibilityProxy.kt`

**新增方法**：
```kotlin
fun isMediaProjectionGranted(): Boolean
suspend fun captureScreen(): String  // 返回截图文件路径
fun getMediaProjectionStatus(): String
```

### 8. 更新 DeviceController
**文件位置**：`app/src/main/java/com/xiaomo/androidforclaw/DeviceController.kt`

**修改**：
- ✅ `getScreenshot()` 现在调用 `AccessibilityProxy.captureScreen()`
- ✅ 从文件路径加载 Bitmap
- ✅ 移除对主应用 MediaProjectionHelper 的直接调用

### 9. 更新 MainActivity 权限页面
**文件位置**：`app/src/main/java/com/xiaomo/androidforclaw/ui/activity/MainActivity.kt`

**修改**：
- ✅ 使用 `AccessibilityProxy.isMediaProjectionGranted()` 检查权限
- ✅ 显示 `AccessibilityProxy.getMediaProjectionStatus()` 状态
- ✅ 移除对主应用 MediaProjectionHelper 的引用
- ✅ 录屏权限请求改为提示用户"由无障碍服务管理"

### 10. 更新 PermissionsActivity
**文件位置**：`app/src/main/java/com/xiaomo/androidforclaw/ui/activity/PermissionsActivity.kt`

**修改**：
- ✅ 使用 `AccessibilityProxy` 替代 MediaProjectionHelper
- ✅ 录屏权限按钮点击时弹出对话框
- ✅ 对话框提供按钮跳转到无障碍服务 APK 的 PermissionActivity
- ✅ 使用 `ComponentName` 启动独立 APK 的 Activity

### 11. 更新 AndroidManifest
**accessibility-service/AndroidManifest.xml**：
- ✅ 添加 `FOREGROUND_SERVICE` 权限
- ✅ 添加 `POST_NOTIFICATIONS` 权限
- ✅ 声明 ForegroundService（foregroundServiceType="mediaProjection"）
- ✅ 声明 PermissionActivity（exported=true, LAUNCHER intent-filter）

## 🏗️ 架构对比

### 原架构（同进程）
```
androidforclaw (Main App)
├── PhoneAccessibilityService
├── MediaProjectionHelper
└── Tools/Skills
```

### 新架构（跨进程 AIDL）
```
androidforclaw (Main App)           accessibility-service (Standalone App)
├── AccessibilityProxy              ├── PhoneAccessibilityService
├── Tools/Skills                    ├── MediaProjectionHelper
└── DeviceController                ├── ForegroundService
                                    ├── PermissionActivity
                                    └── AccessibilityBinder (AIDL)
                    ↕ AIDL IPC (传递文件路径而非图片数据)
```

## 🎯 实现效果

### 主应用 (com.xiaomo.androidforclaw.debug)
- ✅ 不再直接请求录屏权限
- ✅ 通过 AccessibilityProxy 跨进程调用截图功能
- ✅ UI 显示录屏权限状态（来自 AIDL）
- ✅ 提供按钮跳转到无障碍服务 APK 授权界面

### 无障碍服务 APK (com.xiaomo.androidforclaw.accessibility)
- ✅ 提供 PermissionActivity 用于授予权限
- ✅ 管理 MediaProjectionHelper 生命周期
- ✅ 通过 AIDL 提供截图功能
- ✅ 截图保存到独立目录
- ✅ 独立生命周期，不受主应用影响

## 🔧 使用方式

### 用户操作流程

1. **安装两个 APK**：
   - 主应用：`com.xiaomo.androidforclaw.debug`
   - 无障碍服务：`com.xiaomo.androidforclaw.accessibility`

2. **启用无障碍服务**：
   - 系统设置 → 无障碍 → 启用 "AndroidForClaw Accessibility"

3. **授予录屏权限**：

   **方式 1（推荐）**：从主应用跳转
   - 打开主应用
   - 进入 "权限管理"
   - 点击 "录屏权限" → "去授权"
   - 在弹出的权限管理界面点击 "授予录屏权限"

   **方式 2**：直接从桌面启动
   - 在桌面找到 "AndroidForClaw Accessibility" 应用图标
   - 点击启动，进入权限管理界面
   - 点击 "授予录屏权限"

4. **验证权限**：
   - 返回主应用
   - 权限状态应显示 "已授权"

## 🧪 测试验证

### 已验证功能
1. ✅ 两个 APK 编译成功
2. ✅ 安装到设备成功
3. ✅ AccessibilityBinderService 启动成功
4. ✅ MediaProjectionHelper 目录初始化成功
5. ✅ PermissionActivity 启动成功
6. ✅ AIDL 接口绑定成功
7. ✅ 主应用显示正确的权限状态

### 待验证功能
- ⏳ 实际授予 MediaProjection 权限
- ⏳ 跨进程截图功能测试
- ⏳ 主应用崩溃后截图功能独立运行
- ⏳ 性能测试（截图延迟、内存占用）

## 📊 技术亮点

### 1. 跨进程数据传输优化
**问题**：Bitmap 通过 AIDL 传输有大小限制（Parcel 限制 ~1MB）

**解决方案**：
- ✅ 截图保存到文件
- ✅ AIDL 只传递文件路径（String）
- ✅ 主应用从文件路径加载 Bitmap
- ✅ 避免了大数据跨进程传输的性能问题

### 2. 权限管理用户体验
**优势**：
- ✅ 用户友好的 Dialog 界面
- ✅ 实时显示权限状态
- ✅ 从主应用一键跳转授权
- ✅ 也可从桌面直接访问

### 3. 独立生命周期
**优势**：
- ✅ 主应用崩溃不影响截图服务
- ✅ 权限只需授予一次
- ✅ 服务稳定性更高

## 📁 关键文件总结

### accessibility-service 模块
```
accessibility-service/
├── src/main/
│   ├── aidl/com/xiaomo/androidforclaw/aidl/
│   │   └── IAccessibilityService.aidl  (扩展了截图方法)
│   ├── java/com/xiaomo/androidforclaw/accessibility/
│   │   ├── MediaProjectionHelper.kt  (移动自主应用)
│   │   ├── ForegroundService.kt  (新建)
│   │   ├── PermissionActivity.kt  (新建)
│   │   └── service/
│   │       ├── AccessibilityBinder.java  (扩展了截图实现)
│   │       └── AccessibilityBinderService.kt  (初始化截图目录)
│   └── AndroidManifest.xml  (添加权限和 Activity)
```

### 主应用
```
app/
├── src/main/
│   ├── aidl/  (AIDL 接口副本，保持同步)
│   └── java/com/xiaomo/androidforclaw/
│       ├── accessibility/
│       │   └── AccessibilityProxy.kt  (新增截图方法)
│       ├── DeviceController.kt  (更新使用 Proxy)
│       └── ui/activity/
│           ├── MainActivity.kt  (更新权限显示)
│           └── PermissionsActivity.kt  (跳转到无障碍服务授权)
```

## 🎉 总结

通过将 MediaProjection 拆分到无障碍服务 APK，实现了：

1. **架构优化**：权限集中管理，职责清晰分离
2. **稳定性提升**：独立生命周期，互不影响
3. **用户体验**：一次授权，持久生效
4. **性能优化**：文件路径传输，避免大数据 IPC
5. **可维护性**：模块化设计，易于扩展

下一步可以考虑：
- 添加截图质量配置
- 实现截图历史管理
- 优化截图性能（减少延迟）
- 添加更多权限管理功能
