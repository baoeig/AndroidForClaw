# AndroidForClaw 多语言支持文档

## 概述

AndroidForClaw 现已支持多语言界面，目前支持：
- ✅ **英文** (English)
- ✅ **中文** (简体中文)
- ✅ **系统语言** (跟随系统设置)

---

## 📁 资源文件结构

```
app/src/main/res/
├── values/                    # 默认资源（英文）
│   ├── strings.xml           # 英文字符串
│   └── arrays.xml            # 语言选项数组
├── values-zh/                # 中文资源
│   └── strings.xml           # 中文字符串
└── values-zh-rCN/            # 简体中文（可选）
    └── strings.xml

accessibility-service/src/main/res/
├── values/                    # 默认资源（英文）
│   └── strings.xml
└── values-zh/                # 中文资源
    └── strings.xml
```

---

## 🔧 使用方法

### 1. 在代码中使用字符串资源

**推荐做法：使用字符串资源**

```kotlin
// ✅ 正确 - 使用字符串资源（支持多语言）
Toast.makeText(context, R.string.permission_granted, Toast.LENGTH_SHORT).show()
textView.text = getString(R.string.agent_running)
```

**避免硬编码字符串**

```kotlin
// ❌ 错误 - 硬编码字符串（无法多语言）
Toast.makeText(context, "权限已授予", Toast.LENGTH_SHORT).show()
textView.text = "Agent Running"
```

### 2. 动态切换语言

使用 `LocaleHelper` 工具类：

```kotlin
import com.xiaomo.androidforclaw.util.LocaleHelper

// 切换到中文
LocaleHelper.setLocale(context, LocaleHelper.LANGUAGE_CHINESE)

// 切换到英文
LocaleHelper.setLocale(context, LocaleHelper.LANGUAGE_ENGLISH)

// 跟随系统语言
LocaleHelper.setLocale(context, LocaleHelper.LANGUAGE_SYSTEM)

// 获取当前语言
val currentLanguage = LocaleHelper.getLanguage(context)

// 获取当前语言显示名称
val displayName = LocaleHelper.getLanguageDisplayName(context)
// 返回: "中文" / "English" / "System / 系统"
```

### 3. 在 Activity 中应用语言设置

**方法 A: 在 attachBaseContext 中应用**

```kotlin
class MainActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.applyLanguage(newBase))
    }
}
```

**方法 B: 在 Application 中全局应用**

```kotlin
class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // 应用保存的语言设置
        LocaleHelper.applyLanguage(this)
    }
}
```

### 4. 创建语言选择界面

使用 Spinner 或 Dialog：

```kotlin
// 获取所有可用语言
val languages = LocaleHelper.getAvailableLanguages()
// 返回: [LanguageOption("system", "System / 系统"), ...]

val languageNames = languages.map { it.displayName }
val languageCodes = languages.map { it.code }

// 显示选择对话框
AlertDialog.Builder(context)
    .setTitle(R.string.language_setting)
    .setItems(languageNames.toTypedArray()) { _, which ->
        val selectedCode = languageCodes[which]
        LocaleHelper.setLocale(context, selectedCode)

        // 提示重启应用
        Toast.makeText(context, R.string.language_change_restart, Toast.LENGTH_LONG).show()

        // 重启应用
        restartApp()
    }
    .show()
```

### 5. 重启应用以应用语言更改

```kotlin
fun restartApp() {
    val intent = packageManager.getLaunchIntentForPackage(packageName)
    intent?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(intent)
    Process.killProcess(Process.myPid())
}
```

---

## 📝 添加新的字符串资源

### 步骤 1: 在英文资源中添加字符串

`app/src/main/res/values/strings.xml`:

```xml
<string name="new_feature_title">New Feature</string>
<string name="new_feature_message">This is a new feature</string>
```

### 步骤 2: 在中文资源中添加翻译

`app/src/main/res/values-zh/strings.xml`:

```xml
<string name="new_feature_title">新功能</string>
<string name="new_feature_message">这是一个新功能</string>
```

### 步骤 3: 在代码中使用

```kotlin
textView.text = getString(R.string.new_feature_title)
```

---

## 🌐 支持的字符串资源

### 通用操作
- `add`, `delete`, `edit`, `cancel`, `done`, `help`, `more`, `share`

### 权限相关
- `permission_granted`, `permission_denied`
- `accessibility_enabled`, `accessibility_disabled`
- `screen_capture_granted`, `screen_capture_denied`

### 状态信息
- `loading`, `processing`, `success`, `failed`, `error`, `warning`, `info`

### Agent 相关
- `agent_running`, `agent_stopped`, `agent_error`

### 会话相关
- `session_created`, `session_loaded`, `session_saved`, `session_deleted`

### 技能和工具
- `skill_loaded`, `skill_executing`, `skill_execution_failed`
- `tool_executing`, `tool_execution_success`, `tool_execution_failed`

### Gateway 相关
- `gateway_starting`, `gateway_started`, `gateway_stopped`, `gateway_error`

### WebSocket 相关
- `websocket_connecting`, `websocket_connected`, `websocket_disconnected`

**完整列表请查看：**
- `app/src/main/res/values/strings.xml` (英文)
- `app/src/main/res/values-zh/strings.xml` (中文)

---

## 🔍 格式化字符串

### 使用占位符

```xml
<!-- strings.xml -->
<string name="minutes_ago">%d minutes ago</string>
<string name="unknown_opcode">Unknown opcode: %s</string>
```

```kotlin
// 使用
val text1 = getString(R.string.minutes_ago, 5)  // "5 minutes ago"
val text2 = getString(R.string.unknown_opcode, "INVALID")  // "Unknown opcode: INVALID"
```

---

## ⚠️ 注意事项

### 1. 不要翻译的内容

某些字符串不应翻译，使用 `translatable="false"` 标记：

```xml
<string name="developer_url" translatable="false">https://github.com/openclaw/openclaw</string>
<string name="api_key" translatable="false">sk-1234567890abcdef</string>
```

### 2. 保持占位符一致

翻译时，确保占位符（`%s`, `%d`）在所有语言中保持一致：

```xml
<!-- ✅ 正确 -->
<string name="minutes_ago">%d minutes ago</string>      <!-- 英文 -->
<string name="minutes_ago">%d 分钟前</string>           <!-- 中文 -->

<!-- ❌ 错误 -->
<string name="minutes_ago">%d minutes ago</string>      <!-- 英文 -->
<string name="minutes_ago">分钟前</string>               <!-- 中文 - 缺少 %d -->
```

### 3. 测试所有语言

切换语言后，测试所有功能以确保：
- 文本显示正确
- 布局没有被截断
- 占位符正确替换

---

## 🚀 测试多语言

### 方法 1: 通过代码切换

```kotlin
// 在 App 启动时或设置界面
LocaleHelper.setLocale(this, LocaleHelper.LANGUAGE_CHINESE)
```

### 方法 2: 通过系统设置切换

1. 打开系统设置 → 语言和输入法
2. 将中文设置为首选语言
3. 重启应用

### 方法 3: 使用 ADB 命令测试

```bash
# 切换到中文
adb shell setprop persist.sys.locale zh-CN
adb shell stop
adb shell start

# 切换回英文
adb shell setprop persist.sys.locale en-US
adb shell stop
adb shell start
```

---

## 📦 已完成的多语言适配

### 主应用模块 (app)
- ✅ 基础 UI 字符串（按钮、操作等）
- ✅ 权限相关提示
- ✅ Agent 状态信息
- ✅ 会话管理
- ✅ Gateway 和 WebSocket
- ✅ 错误和警告信息

### 无障碍服务模块 (accessibility-service)
- ✅ 服务名称和描述
- ✅ 权限请求界面
- ✅ Toast 提示信息
- ✅ 通知消息

---

## 🔮 后续计划

### 待添加语言
- 🇯🇵 日语 (Japanese) - `values-ja`
- 🇰🇷 韩语 (Korean) - `values-ko`
- 🇫🇷 法语 (French) - `values-fr`
- 🇩🇪 德语 (German) - `values-de`

### 待完善功能
- [ ] 语言设置界面 UI
- [ ] 实时语言切换（无需重启）
- [ ] 自动检测系统语言变化
- [ ] 更多模块的多语言支持

---

## 📚 参考资源

- [Android 官方：支持不同的语言和文化](https://developer.android.com/guide/topics/resources/localization)
- [Android 官方：字符串资源](https://developer.android.com/guide/topics/resources/string-resource)
- [Android 官方：应用资源概览](https://developer.android.com/guide/topics/resources/providing-resources)

---

**AndroidForClaw** - 多语言支持 🌍

现已支持：English | 中文
