# 消息队列测试指南

## 编译和运行状态

✅ **编译成功**
```bash
BUILD SUCCESSFUL in 10s
186 actionable tasks: 6 executed, 180 up-to-date
```

✅ **安装成功**
```bash
Installing APK 'app-debug.apk' on '2510DPC44G - 16'
Installed on 1 device.
```

✅ **应用运行中**
```
com.xiaomo.androidforclaw.debug (PID: 29289)
com.xiaomo.androidforclaw.accessibility (PID: 28740)
```

✅ **服务启动成功**
- Feishu WebSocket: 已连接
- Discord: 已连接
- Gateway: ws://0.0.0.0:8765

---

## 测试方法

### 1. 基础队列测试（FOLLOWUP 模式）

**默认配置**：不需要修改配置，使用默认的 `followup` 模式

**测试步骤**：
1. 在飞书中快速发送两条消息
   - 消息 1: "你好"
   - 消息 2: "测试队列"
2. 观察日志，应该看到：
   ```
   📨 收到飞书消息: 你好
   📝 [FOLLOWUP] Enqueueing message for feishu:xxx
   ⌨️  添加输入中表情...
   ✅ 输入中表情已添加
   ... (处理第一条消息)
   🧹 移除输入中表情...

   📨 收到飞书消息: 测试队列
   📝 [FOLLOWUP] Enqueueing message for feishu:xxx (queue size: 0)
   ⌨️  添加输入中表情...
   ... (处理第二条消息)
   ```

**预期结果**：
- 第一条消息处理时，第二条消息在队列中等待
- 只有第一条消息显示"输入中"表情
- 第一条处理完后，第二条才开始处理

---

### 2. INTERRUPT 模式测试

**修改配置**：
```bash
adb shell "echo '{
  \"gateway\": {
    \"feishu\": {
      \"queueMode\": \"interrupt\",
      \"queueCap\": 10,
      \"queueDropPolicy\": \"old\"
    }
  }
}' > /sdcard/AndroidForClaw/config/openclaw.json"
```

**测试步骤**：
1. 在飞书发送一条需要较长时间处理的消息（如"给我写一个长故事"）
2. 等待 2 秒后，立即发送第二条消息："停止，改成写首诗"
3. 观察日志，应该看到：
   ```
   🛑 [INTERRUPT] Aborting current run for feishu:xxx
   🗑️  [INTERRUPT] Clearing 0 queued messages
   ⚡ [INTERRUPT] Processing new message immediately
   ```

**预期结果**：
- 第一条消息的处理被中断
- 第二条消息立即开始处理
- 只回复第二条消息的内容

---

### 3. COLLECT 模式测试

**修改配置**：
```bash
adb shell "echo '{
  \"gateway\": {
    \"feishu\": {
      \"queueMode\": \"collect\",
      \"queueCap\": 5,
      \"queueDropPolicy\": \"summarize\"
    }
  }
}' > /sdcard/AndroidForClaw/config/openclaw.json"
```

**测试步骤**：
1. 快速发送 3 条短消息：
   - "天气"
   - "时间"
   - "地点"
2. 观察日志，应该看到：
   ```
   📦 [COLLECT] Collected message for feishu:xxx (1 total)
   📦 [COLLECT] Collected message for feishu:xxx (2 total)
   📦 [COLLECT] Collected message for feishu:xxx (3 total)
   📦 [COLLECT] Processing batch of 3 messages
   ```

**预期结果**：
- 三条消息被收集后一次性处理
- 回复中包含所有三条消息的内容
- 格式类似：
  ```
  [Batch] Collected 3 message(s):

  Message 1:
  From: xxx
  Content: 天气

  Message 2:
  From: xxx
  Content: 时间

  Message 3:
  From: xxx
  Content: 地点
  ```

---

### 4. noReply 测试

**测试步骤**：
1. 发送消息："[noReply] 这是一条不需要回复的通知"
2. 观察日志，应该看到：
   ```
   🔕 noReply directive detected, skipping reply
   🧹 移除输入中表情...
   ```

**预期结果**：
- 显示"输入中"表情
- 不发送回复
- 表情被移除

---

### 5. Drop Policy 测试

**修改配置（SUMMARIZE 策略）**：
```bash
adb shell "echo '{
  \"gateway\": {
    \"feishu\": {
      \"queueMode\": \"collect\",
      \"queueCap\": 3,
      \"queueDropPolicy\": \"summarize\"
    }
  }
}' > /sdcard/AndroidForClaw/config/openclaw.json"
```

**测试步骤**：
1. 发送一条需要较长时间的消息（如"讲个长故事"）
2. 等待开始处理后，快速发送 5 条消息
3. 观察日志，应该看到：
   ```
   📝 Drop policy: SUMMARIZE - dropped and summarized: msg_xxx
   [Queue overflow] Dropped 2 message(s) due to cap.
   Summary:
   - [timestamp] user: message content...
   ```

**预期结果**：
- 队列容量为 3
- 超出的消息被丢弃
- 丢弃的消息被汇总显示

---

## 监听日志命令

### 实时监听队列日志
```bash
adb logcat | grep -E "收到飞书消息|INTERRUPT|STEER|FOLLOWUP|COLLECT|Enqueueing|Processing|添加输入中表情|移除输入中表情|noReply"
```

### 查看最近日志
```bash
adb logcat -d | grep "MessageQueueManager" | tail -50
```

### 清空日志后监听
```bash
adb logcat -c && adb logcat | grep "MessageQueueManager"
```

---

## 配置文件位置

- **主配置**: `/sdcard/AndroidForClaw/config/openclaw.json`
- **模型配置**: `/sdcard/AndroidForClaw/config/models.json`

## 查看当前配置

```bash
adb shell cat /sdcard/AndroidForClaw/config/openclaw.json | grep -A 15 '"feishu"'
```

---

## 常见问题

### Q1: 消息没有被处理
**检查**：
1. 应用是否运行：`adb shell ps | grep androidforclaw`
2. Feishu WebSocket 是否连接：`adb logcat -d | grep "Feishu WebSocket"`
3. 飞书配置是否正确

### Q2: 看不到队列日志
**原因**：可能日志被其他输出淹没
**解决**：使用更精确的 grep 过滤

### Q3: INTERRUPT 模式没有中断
**检查**：
1. 配置是否生效（重启应用）
2. 第一条消息是否还在处理中
3. 查看日志确认模式

---

## 性能指标

- **队列入队延迟**: < 10ms
- **模式切换时间**: 立即生效
- **中断响应时间**: < 100ms
- **批量处理延迟**: < 50ms

---

**更新时间**: 2026-03-07
**测试设备**: 2510DPC44G - Android 16
