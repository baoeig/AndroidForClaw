# 飞书消息格式化修复

## 问题描述

飞书收到的消息卡片没有格式化，代码块和 Markdown 表格显示不正常。

## 根本原因

Android 端缺少 OpenClaw 的自动卡片检测逻辑：
- OpenClaw 会自动检测消息中的代码块（` ``` `）和 Markdown 表格（`|...|`）
- 如果包含这些内容，使用 **interactive card (schema 2.0)** 发送
- Android 端之前只发送普通的 text/post 消息，无法正确渲染 Markdown

## OpenClaw 的实现

参考文件：`/Users/qiao/file/forclaw/OpenClaw/extensions/feishu/src/outbound.ts`

```typescript
// 检测是否应该使用卡片
function shouldUseCard(text: string): boolean {
  return /```[\s\S]*?```/.test(text) || /\|.+\|[\r\n]+\|[-:| ]+\|/.test(text);
}

// 构建 Markdown 卡片
export function buildMarkdownCard(text: string): Record<string, unknown> {
  return {
    schema: "2.0",
    config: {
      wide_screen_mode: true,
    },
    body: {
      elements: [
        {
          tag: "markdown",
          content: text,
        },
      ],
    },
  };
}

// 发送逻辑
if (renderMode === "card" || (renderMode === "auto" && shouldUseCard(text))) {
  return sendMarkdownCardFeishu({ cfg, to, text, accountId, replyToMessageId });
}
```

## 解决方案

### 1. 添加 `shouldUseCard()` 函数

```kotlin
/**
 * 检测是否应该使用卡片格式
 * 对齐 OpenClaw: /```[\s\S]*?```/.test(text) || /\|.+\|[\r\n]+\|[-:| ]+\|/.test(text)
 */
private fun shouldUseCard(text: String): Boolean {
    // 检测代码块 ```
    if (text.contains("```")) {
        return true
    }

    // 检测 Markdown 表格 |...|
    val lines = text.lines()
    for (i in 0 until lines.size - 1) {
        val line = lines[i]
        val nextLine = lines.getOrNull(i + 1) ?: continue

        // 检查是否是表格行（包含 |）
        if (line.contains("|")) {
            // 检查下一行是否是分隔符（如 |---|---| 或 |:-:|:-:|）
            if (nextLine.matches(Regex("^\\s*\\|[-:| ]+\\|\\s*$"))) {
                return true
            }
        }
    }

    return false
}
```

### 2. 添加 `buildMarkdownCard()` 函数

```kotlin
/**
 * 构建 Markdown 卡片
 * 对齐 OpenClaw buildMarkdownCard()
 *
 * Uses schema 2.0 format for proper markdown rendering (code blocks, tables, etc.)
 */
private fun buildMarkdownCard(
    text: String,
    mentionTargets: List<MentionTarget> = emptyList()
): String {
    // 处理 @提及
    val cardText = if (mentionTargets.isNotEmpty()) {
        buildMentionedCardContent(text, mentionTargets)
    } else {
        text
    }

    val card = mapOf(
        "schema" to "2.0",
        "config" to mapOf(
            "wide_screen_mode" to true
        ),
        "body" to mapOf(
            "elements" to listOf(
                mapOf(
                    "tag" to "markdown",
                    "content" to cardText
                )
            )
        )
    )

    return gson.toJson(card)
}
```

### 3. 添加 `RenderMode` 枚举

```kotlin
/**
 * 渲染模式（对齐 OpenClaw）
 */
enum class RenderMode {
    /** 自动检测（默认） */
    AUTO,
    /** 强制使用卡片 */
    CARD,
    /** 强制使用文本 */
    TEXT
}
```

### 4. 修改 `sendTextMessage()` 逻辑

```kotlin
suspend fun sendTextMessage(
    receiveId: String,
    text: String,
    receiveIdType: String = "open_id",
    mentionTargets: List<MentionTarget> = emptyList(),
    renderMode: RenderMode = RenderMode.AUTO
): Result<SendResult> = withContext(Dispatchers.IO) {
    try {
        // 分块发送（如果超过限制）
        val chunks = chunkText(text, config.textChunkLimit)
        if (chunks.size > 1) {
            return@withContext sendChunkedMessages(receiveId, chunks, receiveIdType)
        }

        // 判断是否使用卡片（对齐 OpenClaw）
        val useCard = when (renderMode) {
            RenderMode.CARD -> true
            RenderMode.TEXT -> false
            RenderMode.AUTO -> shouldUseCard(text)
        }

        if (useCard) {
            // 使用 Markdown 卡片发送（正确渲染代码块和表格）
            Log.d(TAG, "Using markdown card for formatted content")
            val card = buildMarkdownCard(text, mentionTargets)
            return@withContext sendCard(receiveId, card, receiveIdType)
        } else {
            // 使用普通文本消息
            val content = if (mentionTargets.isNotEmpty()) {
                buildMentionedTextContent(text, mentionTargets)
            } else {
                buildTextContent(text)
            }
            return@withContext sendMessageInternal(receiveId, "text", content, receiveIdType)
        }

    } catch (e: Exception) {
        Log.e(TAG, "Failed to send text message", e)
        Result.failure(e)
    }
}
```

## 对比差异

| 特性 | 修复前 | 修复后 |
|------|--------|--------|
| 代码块渲染 | ❌ 显示为纯文本 | ✅ 正确高亮渲染 |
| Markdown 表格 | ❌ 显示为竖线文本 | ✅ 正确渲染为表格 |
| 自动检测 | ❌ 不支持 | ✅ 自动检测（AUTO 模式） |
| 强制卡片模式 | ❌ 不支持 | ✅ 支持（CARD 模式） |
| 强制文本模式 | ✅ 默认行为 | ✅ 支持（TEXT 模式） |
| @提及支持 | ✅ 支持 | ✅ 卡片中也支持 |

## 测试用例

### 测试 1：代码块

**输入消息**：
```
Here's the code:

\`\`\`kotlin
fun hello() {
    println("Hello World")
}
\`\`\`
```

**预期结果**：
- ✅ 使用卡片发送
- ✅ 代码块正确高亮显示

### 测试 2：Markdown 表格

**输入消息**：
```
Comparison:

| Feature | Android | iOS |
|---------|---------|-----|
| Camera  | ✅      | ✅  |
| GPS     | ✅      | ✅  |
```

**预期结果**：
- ✅ 使用卡片发送
- ✅ 表格正确渲染

### 测试 3：普通文本

**输入消息**：
```
This is a simple text message.
```

**预期结果**：
- ✅ 使用普通文本发送
- ✅ 不创建卡片

### 测试 4：混合内容

**输入消息**：
```
Here's the analysis:

Results:
| Metric | Value |
|--------|-------|
| Speed  | 10ms  |

Code:
\`\`\`python
print("test")
\`\`\`
```

**预期结果**：
- ✅ 使用卡片发送
- ✅ 表格和代码块都正确渲染

## 修改文件

- `extensions/feishu/src/main/java/com/xiaomo/feishu/messaging/FeishuSender.kt`
  - 添加 `shouldUseCard()` 函数
  - 添加 `buildMarkdownCard()` 函数
  - 添加 `buildMentionedCardContent()` 函数
  - 添加 `RenderMode` 枚举
  - 修改 `sendTextMessage()` 逻辑

## API 兼容性

### 向后兼容

现有调用无需修改：
```kotlin
// 之前的调用仍然有效（默认 AUTO 模式）
sender.sendTextMessage(receiveId, text)
```

### 新功能

可以指定渲染模式：
```kotlin
// 强制使用卡片
sender.sendTextMessage(receiveId, text, renderMode = RenderMode.CARD)

// 强制使用文本
sender.sendTextMessage(receiveId, text, renderMode = RenderMode.TEXT)

// 自动检测（默认）
sender.sendTextMessage(receiveId, text, renderMode = RenderMode.AUTO)
```

## Schema 2.0 卡片格式

Feishu Interactive Card Schema 2.0 格式：

```json
{
  "schema": "2.0",
  "config": {
    "wide_screen_mode": true
  },
  "body": {
    "elements": [
      {
        "tag": "markdown",
        "content": "Your **markdown** content here"
      }
    ]
  }
}
```

**优势**：
- ✅ 支持完整的 Markdown 语法
- ✅ 代码块自动高亮
- ✅ 表格正确渲染
- ✅ 支持加粗、斜体、链接等
- ✅ 支持 @提及

## 后续优化

1. **渲染模式配置**
   - 支持在 `FeishuConfig` 中配置默认 renderMode
   - 对齐 OpenClaw 的 `account.config.renderMode`

2. **流式卡片**
   - 参考 OpenClaw 的 `streaming-card.ts`
   - 支持实时更新卡片内容

3. **卡片头部**
   - 支持添加卡片头部（标题、颜色）
   - `StreamingCardHeader` 类型

4. **更复杂的检测**
   - 检测更多 Markdown 语法（如列表、引用等）
   - 可配置检测规则

## 参考资料

- OpenClaw Feishu 扩展: `/Users/qiao/file/forclaw/OpenClaw/extensions/feishu/`
- OpenClaw outbound.ts: `src/outbound.ts`
- OpenClaw send.ts: `src/send.ts`
- OpenClaw streaming-card.ts: `src/streaming-card.ts`
- Feishu Card Kit 文档: https://open.feishu.cn/document/ukTMukTMukTM/uMDMxEjLzATMx4yMwETM

---

**版本**: v2.4.4
**日期**: 2026-03-07
**修复人**: Claude Code
