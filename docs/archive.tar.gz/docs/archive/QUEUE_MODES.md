# 消息队列模式对齐 OpenClaw

## 当前状态

✅ **已完成**:
- KeyedAsyncQueue 基础实现
- 按 chatId 串行处理消息
- Typing indicator 只在实际处理时显示

❌ **待实现**:
1. Queue Mode 支持（interrupt, steer, followup, collect, queue）
2. noReply 逻辑
3. 消息去重（dedupe）
4. Drop policy（old, new, summarize）

---

## OpenClaw 队列模式详解

### 1. interrupt（中断模式）
- 新消息到来时，**立即中断**当前正在运行的 Agent
- 清空队列中的待处理消息
- 立即处理新消息
- 用途：紧急消息，需要立即响应

```typescript
if (resolvedQueue.mode === "interrupt" && laneSize > 0) {
  const cleared = clearCommandLane(sessionLaneKey);
  const aborted = abortEmbeddedPiRun(sessionIdFinal);
}
```

### 2. steer（引导模式）
- 新消息**不会中断** Agent
- 新消息会**传递给正在运行的 Agent**（steer）
- Agent 可以在运行中接收新消息并调整行为
- 用途：对话式交互，用户可以在 Agent 运行时给出指示

```typescript
const shouldSteer = resolvedQueue.mode === "steer" || resolvedQueue.mode === "steer-backlog";
```

### 3. followup（跟进模式）
- 新消息**加入队列**
- 当前 Agent 运行完成后，按顺序处理队列中的消息
- 每条消息独立处理
- 用途：需要顺序处理的场景

### 4. collect（收集模式）
- 新消息**加入队列**
- 当前 Agent 运行完成后，**一次性处理所有排队消息**
- 所有消息一起发送给 Agent
- 用途：批量处理场景

### 5. queue（简单队列）
- 默认行为，简单的 FIFO 队列
- 新消息加入队列，按顺序处理

---

## 实现计划

### Phase 1: 基础 Queue Mode 支持

**文件**:
- `app/src/main/java/com/xiaomo/androidforclaw/core/MessageQueueManager.kt`

**功能**:
1. 支持配置 queue mode（读取 openclaw.json）
2. 实现 interrupt 模式（清空队列 + 中止当前运行）
3. 实现 followup 模式（当前已实现的基本行为）
4. 实现 queue 模式（默认行为）

### Phase 2: Steer 模式支持

**挑战**: 需要在 AgentLoop 运行时接收新消息

**实现方案**:
1. AgentLoop 增加消息队列监听
2. 在每次 LLM 调用前检查是否有新消息
3. 新消息以 user message 形式注入到对话历史

### Phase 3: Collect 模式支持

**功能**:
1. 收集多条消息
2. 达到条件后（时间/数量）一次性处理
3. 生成汇总提示词

### Phase 4: Drop Policy 支持

**三种策略**:
- `old`: 丢弃最旧的消息
- `new`: 拒绝新消息
- `summarize`: 丢弃消息但保留摘要

### Phase 5: noReply 逻辑

**功能**:
- 某些消息不需要回复（如通知、状态更新）
- Agent 可以返回 noReply 指令
- 队列继续处理下一条消息，不发送回复

---

## 配置格式（对齐 OpenClaw）

```json
{
  "messages": {
    "queue": {
      "mode": "followup",
      "debounceMs": 100,
      "cap": 10,
      "dropPolicy": "old"
    },
    "feishu": {
      "queue": {
        "mode": "interrupt"
      }
    }
  }
}
```

---

## 当前优先级

**P0 (立即实现)**:
1. interrupt 模式
2. noReply 逻辑

**P1 (本周完成)**:
3. steer 模式
4. collect 模式

**P2 (下周完成)**:
5. Drop policy
6. 消息去重

---

## 参考文件

OpenClaw:
- `src/auto-reply/reply/get-reply-run.ts` - 队列模式调度
- `src/auto-reply/reply/queue/types.ts` - 队列类型定义
- `src/utils/queue-helpers.ts` - 队列工具函数
- `src/plugin-sdk/keyed-async-queue.ts` - 基础队列实现
