# Skills 系统测试指南

测试 "你有哪些skill" 查询，验证 OpenClaw 对齐是否正确

---

## 快速测试

### 方法 1: 使用测试脚本（推荐）

```bash
cd /Users/qiao/file/forclaw/phoneforclaw
./test_skills_loading.sh
```

脚本会自动：
1. 检查应用是否运行
2. 收集相关日志
3. 分析 Skills 加载情况
4. 给出测试结果

### 方法 2: 手动测试

1. **启动应用**
   ```bash
   ./gradlew installDebug
   adb shell am start -n com.xiaomo.androidforclaw/.ui.activity.MainActivity
   ```

2. **启动日志监控**（新终端）
   ```bash
   adb logcat -s SkillsLoader:D SkillParser:D ContextBuilder:D AgentLoop:D
   ```

3. **在应用中输入查询**
   - 打开聊天界面
   - 输入: "你有哪些skill" 或 "有哪些技能"

4. **观察日志输出**

---

## 期望的日志输出

### ✅ 正常情况

```
SkillsLoader: 开始加载 Skills...
SkillsLoader: 扫描 Bundled Skills: 7 个目录
SkillParser: ✅ Parsed skill: mobile-operations, always=true, emoji=📱
SkillParser: ✅ Parsed skill: bootstrap, always=true, emoji=🤖
SkillParser: ✅ Parsed skill: create-skill, always=false, emoji=🛠️
...
SkillsLoader: Skills 加载完成: 总计 7 个
SkillsLoader:   - Bundled: 7
SkillsLoader:   - Managed: 0 (覆盖)
SkillsLoader:   - Workspace: 0 (覆盖)
SkillsLoader: Always Skills: 2 个

ContextBuilder: 💬 构建系统提示词...
ContextBuilder: ✅ Injected Always Skill: mobile-operations (~3500 tokens)
ContextBuilder: ✅ Injected Always Skill: bootstrap (~2000 tokens)
ContextBuilder: ✅ System prompt 构建完成 (28542 chars)
ContextBuilder: ✅ 预估 Tokens: ~7135

AgentLoop: ========== Agent Loop 开始 ==========
AgentLoop: 🔧 Universal tools: 9
AgentLoop: 📱 Android tools: 12
AgentLoop: ✅ System prompt added (28542 chars)
AgentLoop: ✅ User message: 你有哪些skill
AgentLoop: 📤 准备发送第一次 LLM 请求...
```

### ❌ 异常情况

**情况 1: metadata 解析失败**
```
SkillParser: ❌ metadata 解析失败: Expected a JsonObject but was JsonPrimitive
SkillsLoader: Always Skills: 0 个
```
**解决**: 检查 `assets/skills/*/SKILL.md` 的 metadata 格式

**情况 2: Skills 未注入**
```
ContextBuilder: ✅ System prompt 构建完成 (12000 chars)
# 没有 "Injected Always Skill" 日志
```
**解决**: 检查 `ContextBuilder.buildSkillsSection()` 逻辑

**情况 3: Skills 加载为 0**
```
SkillsLoader: Skills 加载完成: 总计 0 个
```
**解决**: 检查 assets 目录是否正确打包

---

## 验证清单

### 1. Metadata 格式（✅ 已修复）

所有 bundled skills 应该使用正确的 JSON 格式：

```yaml
---
name: mobile-operations
description: Core mobile device operation skills
metadata: { "openclaw": { "always": true, "emoji": "📱" } }
---
```

**检查命令**:
```bash
find app/src/main/assets/skills -name "SKILL.md" -exec head -10 {} \;
```

### 2. SkillsLoader 工作正常

- [x] 正确加载 bundled skills
- [x] 正确解析 metadata (JSON 格式)
- [x] 正确识别 always=true 的技能
- [x] getAlwaysSkills() 返回至少 2 个技能 (mobile-operations + bootstrap)

### 3. ContextBuilder 注入 Skills

- [x] buildSkillsSection() 生成 "Skills (mandatory)" section
- [x] 注入所有 always skills 到系统提示词
- [x] 每个 skill 的 content 都被包含
- [x] 格式对齐 OpenClaw

### 4. AgentLoop 执行

- [x] 系统提示词正确传递给 LLM
- [x] LLM 能看到所有 skills
- [x] LLM 能正确回答 "有哪些skill"

---

## 故障排查

### 问题: Agent 回复 "我没有 skill"

**可能原因 1**: Metadata 格式错误
```bash
# 检查
adb logcat -s SkillParser:D | grep "解析失败\|Exception"

# 修复
1. 检查所有 SKILL.md 的 metadata 格式
2. 确保使用: metadata: { "openclaw": { "always": true } }
3. 重新编译: ./gradlew clean assembleDebug
```

**可能原因 2**: Skills 未注入到提示词
```bash
# 检查
adb logcat -s ContextBuilder:D | grep "Injected"

# 修复
1. 检查 buildSkillsSection() 是否正确调用
2. 检查 getAlwaysSkills() 返回值是否为空
3. 添加 Log.d() 调试输出
```

**可能原因 3**: 系统提示词过大被截断
```bash
# 检查
adb logcat -s ContextBuilder:D | grep "System prompt"

# 如果提示词 > 50000 chars，可能被截断
# 需要优化 skills 内容或使用摘要
```

---

## 期望的 Agent 响应

当用户问 "你有哪些skill" 时，Agent 应该回复类似：

```
我目前拥有以下技能：

1. 📱 mobile-operations（移动操作）
   - 核心 Android 设备操作技能
   - 包括：截图、点击、滑动、输入文本等
   - 用于观察和控制 Android 应用

2. 🤖 bootstrap（系统引导）
   - 系统身份和核心指令
   - 定义了我的角色和能力边界

3. 🛠️ create-skill（技能创建）
   - 创建新技能的元技能
   - 用于扩展我的能力

4. ⚡ javascript-executor（JavaScript 执行）
   - 使用 QuickJS 引擎执行 JavaScript
   - 用于数据处理、文本操作、文件操作

5. 📊 data-processing（数据处理）
   - 使用 JavaScript 进行数据分析

6. 🌐 browser（浏览器自动化）
   - 通过 BrowserForClaw 自动化 Web 浏览器

7. 🐛 debugging（调试）
   - 调试技能和故障排查技术

这些技能帮助我完成各种 Android 自动化任务。
```

---

## 成功标准

✅ 所有检查通过时，表示 Skills 系统正常：

1. SkillsLoader 加载 ≥ 7 个 skills
2. Always Skills ≥ 2 个 (mobile-operations + bootstrap)
3. 无 metadata 解析错误
4. ContextBuilder 注入 ≥ 2 个 skills
5. 系统提示词长度 > 20000 chars
6. AgentLoop 成功启动并执行
7. Agent 能列出所有 skills

---

## 相关文件

- `app/src/main/assets/skills/*/SKILL.md` - Bundled skills
- `app/src/main/java/com/xiaomo/androidforclaw/agent/skills/SkillsLoader.kt` - Skills 加载器
- `app/src/main/java/com/xiaomo/androidforclaw/agent/skills/SkillParser.kt` - Metadata 解析
- `app/src/main/java/com/xiaomo/androidforclaw/agent/context/ContextBuilder.kt` - 系统提示词构建
- `app/src/main/java/com/xiaomo/androidforclaw/core/MainEntryNew.kt` - Agent 入口

---

**测试脚本**: `./test_skills_loading.sh`
**实现总结**: `IMPLEMENTATION_SUMMARY.md`

